int main() {
    int result = createMappingMemory();

    // if (result == 1) {
    //     printf("Memória mapeada.\n");
    // } else {
    //     printf("Falha ao mapear memória\n %d", result);
    // }
    printf("\n\n ok \n\n");

    return 0;
}