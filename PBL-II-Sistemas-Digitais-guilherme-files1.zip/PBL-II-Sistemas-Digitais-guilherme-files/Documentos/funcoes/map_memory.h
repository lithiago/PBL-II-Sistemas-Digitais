#ifndef MAP_MEMORY
#define MAP_MEMORY

// Declarações das funções assembly
extern void* map_memory(size_t size, int* fd);

#endif // FUNCTIONS_H