#ifndef MAPS
#define MAPS

extern int createMappingMemory();

#endif