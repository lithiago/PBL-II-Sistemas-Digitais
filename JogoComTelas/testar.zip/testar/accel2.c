#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>
#include <unistd.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <time.h>

#define I2C0_BASE_ADDR 0xFFC04000
#define IC_CON_OFFSET 0x0
#define MAP_SIZE 0x1000
#define IC_TAR_REG 0x04
#define IC_CON_REG (I2C0_BASE_ADDR + IC_CON_OFFSET)
#define IC_DATA_CMD_REG 0x10
#define IC_ENABLE_REG 0x6C
#define IC_RXFLR_REG 0x78
#define ADXL345_ADDR 0x53
#define DATA_FORMAT 0x31
#define BW_RATE 0x2C
#define POWER_CTL 0x2D
#define ADXL345_REG_DATA_X0 0x32
#define ADXL345_REG_DATA_X1 0x31
#define I2C0_FS_SCL_HCNT 0x1C
#define I2C0_FS_SCL_LCNT 0x20
#define I2C0_ENABLE_STATUS 0x9C

volatile uint32_t *i2c_base;
int16_t accel_x_offset = 0;
int16_t accel_y_offset = 0;
int16_t accel_z_offset = 0;


// Funções de I2C
void write_register(volatile uint32_t *base, uint32_t offset, int32_t value) {
    base[offset / 4] = value;
}

int32_t read_register(volatile uint32_t *base, uint32_t offset) {
    return base[offset / 4];
}

// Funções do acelerômetro
void accel_reg_write(uint8_t addressA, int8_t value) {
    write_register(i2c_base, IC_DATA_CMD_REG, addressA + 0x400);
    write_register(i2c_base, IC_DATA_CMD_REG, value);
}

void accel_reg_read(uint8_t addressA, int8_t *value) {
    write_register(i2c_base, IC_DATA_CMD_REG, addressA + 0x400);
    write_register(i2c_base, IC_DATA_CMD_REG, 0x100);
    while (read_register(i2c_base, IC_RXFLR_REG) == 0) {}
    *value = (int8_t)read_register(i2c_base, IC_DATA_CMD_REG);
}
// Inicialização do I2C
void I2C0_init() {
    write_register(i2c_base, IC_ENABLE_REG, 0x02);
    while ((read_register(i2c_base, I2C0_ENABLE_STATUS) & 0x1) == 1) {}

    write_register(i2c_base, IC_CON_OFFSET, 0x65);
    write_register(i2c_base, IC_TAR_REG, 0x53);
    write_register(i2c_base, I2C0_FS_SCL_HCNT, 90);
    write_register(i2c_base, I2C0_FS_SCL_LCNT, 160);
    write_register(i2c_base, IC_ENABLE_REG, 0x01);
}

// Função de calibração
void calibrate_accel() {
    int8_t x_data_0 = 0;
    int8_t x_data_1 = 0;
    accel_reg_read(ADXL345_REG_DATA_X0, &x_data_0);  // Lê o valor atual do eixo X
    accel_reg_read(ADXL345_REG_DATA_X1, &x_data_1);
    accel_x_offset = x_data_1;
    accel_x_offset = accel_x_offset << 8;
    accel_x_offset += x_data_0;
    printf("Calibração concluída. Offset do eixo X: %d\n", accel_x_offset);
}

void accel_init() {
    accel_reg_write(DATA_FORMAT, 0x0B);
    accel_reg_write(BW_RATE, 0x0B);
    accel_reg_write(POWER_CTL, 0x00);
    accel_reg_write(POWER_CTL, 0x08);
    calibrate_accel();
}

int get_calibrated_accel_x() {
    int8_t x_data_0 = 0;
    int8_t x_data_1 = 0;
    accel_reg_read(ADXL345_REG_DATA_X0, &x_data_0);  // Lê o valor atual do eixo X
    accel_reg_read(ADXL345_REG_DATA_X1, &x_data_1);  // Lê o valor atual do eixo X
    int16_t accel_x = x_data_1;
    accel_x = accel_x << 8;
    accel_x += x_data_0;
    accel_x -= accel_x_offset;  // Subtrai o valor do offset
    return accel_x;
}

int main(){
    // Abrir /dev/mem para acessar a memória do sistema
    int fd1 = open("/dev/mem", O_RDWR | O_SYNC);
    if (fd1 == -1) {
        printf("Erro ao abrir /dev/mem");
        return -1;
    }
    
    i2c_base = (volatile uint32_t *) mmap(NULL, MAP_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, fd1, I2C0_BASE_ADDR);
    if (i2c_base == MAP_FAILED) {
        printf("Erro ao mapear /dev/mem");
        close(fd1);
        return -1;
    }

    I2C0_init();
    accel_init();
    while(1){
                // Escrever no IC_DATA_CMD para solicitar a leitura dos dados de X, Y, Z
                // Enviar o registrador de início de leitura (0x32 - registrador de dados do ADXL345)
                // *((uint32_t *)(i2c_base + IC_DATA_CMD_REG)) = ADXL345_REG_DATA_X0;
                // printf("teste2");

                // // Solicitar leitura de 6 bytes (dados de X, Y, Z)
                // for (int i = 0; i < 6; i++)
                // {
                //     *((uint32_t *)(i2c_base + IC_DATA_CMD_REG)) = 0x100; // Cmd para leitura
                // }

                // // Verificar o IC_RXFLR para garantir que os dados estejam prontos para leitura
                // //while (*((uint32_t *)(i2c_base + IC_RXFLR_REG)) < 6);

                // // Ler os dados do IC_DATA_CMD (6 bytes: 2 para X, 2 para Y, 2 para Z)
                 int16_t accel_data[3] = {0}; // Array para armazenar os valores de X, Y, Z

                // for (int i = 0; i < 3; i++)
                // {
                //     // Lê dois bytes (low byte primeiro, depois o high byte)
                //     uint8_t low_byte = *((uint32_t *)(i2c_base + IC_DATA_CMD_REG)) ;
                //     uint8_t high_byte = *((uint32_t *)(i2c_base + IC_DATA_CMD_REG)) ;
                //     accel_data[i] = (int16_t)((high_byte << 8) | low_byte); // Combinar os dois bytes
                // }
                accel_data[0] = get_calibrated_accel_x();

                printf("\n------------------------------------\n");
                printf("Aceleração em X: %d\n", accel_data[0]);
                printf("Aceleração em Y: %d\n", accel_data[1]);
                printf("Aceleração em Z: %d\n", accel_data[2]);
                printf("\n------------------------------------\n");
            }
            // Desabilitar o I2C0 após a operação
    *((uint32_t *)(i2c_base + IC_ENABLE_REG)) = 0x0;
    printf("I2C desabilitado\n");

    closeMappingMemory();

    // Desmapear a memória e fechar o arquivo de memória
    munmap(i2c_base, MAP_SIZE);
    close(fd1);
}
